import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.SortedMap;


/**
 * Shortest remaining time first scheduler
 */
public class SRTFScheduler implements Scheduler {

  /** Debug flag. */
  private static boolean D = true;

  @Override
  public void schedule(String inputFile, String outputFile) {
    Map<Long, Process> processes = Utils.parse(inputFile);
    List<Process> scheduled = new ArrayList<Process>();

    PriorityQueue<Process> readyQueue = new PriorityQueue<Process>(processes.size(),
        new ExecutionTimeComparator());

    SortedMap<Integer, List<Long>> sortedArrivalMap = Process.sortArrivalTime(processes);
    Iterator<Integer> arrivalTimeIterator = sortedArrivalMap.keySet().iterator();

    Process scheduledProcess = null;
    int current = 0;
    int oldCurrent = 0;
    while (true) {
      if (scheduled.size() == processes.size()) {
        break;
      }

      oldCurrent = current;

      if (D) System.out.println("==============");

      // Get the time on which new processes will arrive
      if (arrivalTimeIterator.hasNext()) {
        int newProcessArrivalTime = arrivalTimeIterator.next();

        // If new processes will arrive, then next scheduling time will be until that
        current = newProcessArrivalTime;

        if (D) System.out.println("@I: Process arrival time:" + newProcessArrivalTime +
            ", arrived processes are:" + sortedArrivalMap.get(newProcessArrivalTime));

        // Add all the arrived processes to readyQueue
        for (Long pid : sortedArrivalMap.get(newProcessArrivalTime)) {
          readyQueue.add(processes.get(pid));
        }
      } else {
        // if no new arriving processes, next scheduling time will be when current process finishes.
        current += scheduledProcess.executionTime;
      }

      if (D) System.out.println("@I: Current time is:" + current);

      if (scheduledProcess != null) {
        if (D) System.out.println("@@@S: Executed process pid:" + scheduledProcess.pid +
            " between=[" + oldCurrent + ", " + current + "]");

        scheduledProcess.executionTime -= (current - oldCurrent);

        // Update all other processes as waiting
        for (Process process : readyQueue) {
          if (current != process.arrivalTime) {
            if (D) System.out.println("Process " + process.pid + " is waiting for " +
                (current-oldCurrent));
            process.waitTime += (current - oldCurrent);
          }
        }

        if (scheduledProcess.executionTime > 0) {
          readyQueue.add(scheduledProcess);
        } else {
          scheduledProcess.finishTime = current;
          scheduledProcess.turnaroundTime = current - scheduledProcess.arrivalTime;
          scheduled.add(scheduledProcess);
          if (D) System.out.println("@@@S: Process " + scheduledProcess.pid + " finished " +
              " execution at time " + current);
        }
      }

      if (D) System.out.println("@I: Ready queue:" + readyQueue);

      // Get the process with the shortest remaining time.
      if (readyQueue.size() > 0) {
        scheduledProcess = readyQueue.poll();
      }
    }

    Utils.write(scheduled, outputFile);
  }

  /** Process comparator according to process executionTime. */
  private class ExecutionTimeComparator implements Comparator<Process> {

    @Override
    public int compare(Process o1, Process o2) {
      return o1.executionTime - o2.executionTime;
    }
  }
}

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.SortedMap;


/**
 * Shortest remaining time first scheduler
 */
public class SRTFScheduler implements Scheduler {

  /** Debug flag. */
  private static boolean D = true;

  @Override
  public void schedule(String inputFile, String outputFile) {
    Map<Long, Process> processes = Utils.parse(inputFile);
    List<Process> scheduled = new ArrayList<Process>();

    PriorityQueue<Process> readyQueue = new PriorityQueue<Process>(processes.size(),
        new ExecutionTimeComparator());

    SortedMap<Integer, List<Long>> sortedArrivalMap = Process.sortArrivalTime(processes);
    Iterator<Integer> arrivalTimeIterator = sortedArrivalMap.keySet().iterator();

    Process scheduledProcess = null;
    int current = 0;
    int oldCurrent = 0;
    while (true) {
      if (scheduled.size() == processes.size()) {
        break;
      }

      oldCurrent = current;

      if (D) System.out.println("==============");

      // Get the time on which new processes will arrive
      if (arrivalTimeIterator.hasNext()) {
        int newProcessArrivalTime = arrivalTimeIterator.next();

        // If new processes will arrive, then next scheduling time will be until that
        current = newProcessArrivalTime;

        if (D) System.out.println("@I: Process arrival time:" + newProcessArrivalTime +
            ", arrived processes are:" + sortedArrivalMap.get(newProcessArrivalTime));

        // Add all the arrived processes to readyQueue
        for (Long pid : sortedArrivalMap.get(newProcessArrivalTime)) {
          readyQueue.add(processes.get(pid));
        }
      } else {
        // if no new arriving processes, next scheduling time will be when current process finishes.
        current += scheduledProcess.executionTime;
      }

      if (D) System.out.println("@I: Current time is:" + current);

      if (scheduledProcess != null) {
        if (D) System.out.println("@@@S: Executed process pid:" + scheduledProcess.pid +
            " between=[" + oldCurrent + ", " + current + "]");

        scheduledProcess.executionTime -= (current - oldCurrent);

        // Update all other processes as waiting
        for (Process process : readyQueue) {
          if (current != process.arrivalTime) {
            if (D) System.out.println("Process " + process.pid + " is waiting for " +
                (current-oldCurrent));
            process.waitTime += (current - oldCurrent);
          }
        }

        if (scheduledProcess.executionTime > 0) {
          readyQueue.add(scheduledProcess);
        } else {
          scheduledProcess.finishTime = current;
          scheduledProcess.turnaroundTime = current - scheduledProcess.arrivalTime;
          scheduled.add(scheduledProcess);
          if (D) System.out.println("@@@S: Process " + scheduledProcess.pid + " finished " +
              " execution at time " + current);
        }
      }

      if (D) System.out.println("@I: Ready queue:" + readyQueue);

      // Get the process with the shortest remaining time.
      if (readyQueue.size() > 0) {
        scheduledProcess = readyQueue.poll();
      }
    }

    Utils.write(scheduled, outputFile);
  }

  /** Process comparator according to process executionTime. */
  private class ExecutionTimeComparator implements Comparator<Process> {

    @Override
    public int compare(Process o1, Process o2) {
      return o1.executionTime - o2.executionTime;
    }
  }
}
